# lib-tracker-app
Desktop implementation of lib-tracker

- Remove settings
- Remove modify users in navbar
- Fix dash width
- Fix to login popup?
